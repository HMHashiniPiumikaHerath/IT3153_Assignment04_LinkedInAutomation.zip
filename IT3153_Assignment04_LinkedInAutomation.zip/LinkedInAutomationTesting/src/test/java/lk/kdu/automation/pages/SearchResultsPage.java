package lk.kdu.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SearchResultsPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By resultsContainer = By.cssSelector("div.search-results-container, main");
    private final By resultItems      = By.cssSelector("li.reusable-search__result-container, div[data-view-name='search-entity-result-universal-template']");
    private final By peopleFilter     = By.xpath("//button[normalize-space()='People']");

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public boolean isLoaded() {
        try {
            wait.until(ExpectedConditions.urlContains("/search/results"));
            return wait.until(ExpectedConditions.visibilityOfElementLocated(resultsContainer)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public int getResultCount() {
        List<WebElement> items = wait.until(
                ExpectedConditions.presenceOfAllElementsLocatedBy(resultItems));
        return items.size();
    }

    public void filterByPeople() {
        wait.until(ExpectedConditions.elementToBeClickable(peopleFilter)).click();
    }
}