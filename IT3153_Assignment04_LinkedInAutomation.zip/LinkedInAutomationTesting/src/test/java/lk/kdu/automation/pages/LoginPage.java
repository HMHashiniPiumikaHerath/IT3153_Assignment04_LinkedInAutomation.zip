
package lk.kdu.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // LinkedIn login fields
    private final By usernameField =
            By.cssSelector("input[type='email']");

    private final By passwordField =
            By.cssSelector("input[type='password']");

    // Login error messages
    private final By errorMessages =
            By.cssSelector(
                    "#error-for-password, #error-for-username, [role='alert'], .form__label--error"
            );

    // Constructor
    public LoginPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    // Find visible and enabled element
    private WebElement findVisibleElement(
            WebDriver currentDriver, By locator) {

        List<WebElement> elements =
                currentDriver.findElements(locator);

        for (WebElement element : elements) {

            if (element.isDisplayed() && element.isEnabled()) {
                return element;
            }
        }

        return null;
    }

    // Open LinkedIn login page
    public void openLoginPage() {

        driver.get("https://www.linkedin.com/login");

        try {

            wait.until(d -> {

                boolean usernameVisible =
                        findVisibleElement(d, usernameField) != null;

                String url = d.getCurrentUrl();

                boolean securityPage =
                        url.contains("checkpoint")
                                || url.contains("authwall");

                boolean loggedIn =
                        url.contains("/feed");

                return usernameVisible || securityPage || loggedIn;
            });

        } catch (Exception e) {

            System.out.println(
                    "LinkedIn URL: " + driver.getCurrentUrl()
            );

            System.out.println(
                    "Page Title: " + driver.getTitle()
            );

            System.out.println("----- INPUT FIELD DETAILS -----");

            for (WebElement input :
                    driver.findElements(By.tagName("input"))) {

                System.out.println(
                        "Type: " + input.getAttribute("type")
                                + " | ID: " + input.getAttribute("id")
                                + " | Name: " + input.getAttribute("name")
                                + " | Displayed: " + input.isDisplayed()
                );
            }

            System.out.println("----- END INPUT DETAILS -----");

            throw new RuntimeException(
                    "LinkedIn login page could not be detected.", e
            );
        }

        System.out.println(
                "Current LinkedIn URL: " + driver.getCurrentUrl()
        );

        System.out.println(
                "Current Page Title: " + driver.getTitle()
        );
    }

    // Enter email
    public void enterUsername(String username) {

        WebElement element = wait.until(
                d -> findVisibleElement(d, usernameField)
        );

        element.clear();
        element.sendKeys(username);

        System.out.println("Email entered successfully.");
    }

    // Enter password
    public void enterPassword(String password) {

        WebElement element = wait.until(
                d -> findVisibleElement(d, passwordField)
        );

        element.clear();
        element.sendKeys(password);

        System.out.println("Password entered successfully.");
    }

    // Click Sign In button
    public void clickSignIn() {

        try {

            WebElement button = wait.until(d -> {

                for (WebElement element :
                        d.findElements(By.tagName("button"))) {

                    if (element.isDisplayed()
                            && element.isEnabled()) {

                        String text = element.getText().trim();

                        if (text.equalsIgnoreCase("Sign in")) {
                            return element;
                        }
                    }
                }

                return null;
            });

            button.click();

            System.out.println("Sign In button clicked.");

        } catch (Exception e) {

            System.out.println("----- BUTTON DETAILS -----");

            for (WebElement button :
                    driver.findElements(By.tagName("button"))) {

                System.out.println(
                        "Text: " + button.getText()
                                + " | Type: " + button.getAttribute("type")
                                + " | ID: " + button.getAttribute("id")
                                + " | Displayed: " + button.isDisplayed()
                                + " | Enabled: " + button.isEnabled()
                );
            }

            System.out.println("----- END BUTTON DETAILS -----");

            throw new RuntimeException(
                    "Sign In button could not be clicked.", e
            );
        }
    }

    // Login using email and password
    public void login(String username, String password) {

        enterUsername(username);

        enterPassword(password);

        clickSignIn();
    }

    // Check login error
    public boolean isLoginErrorDisplayed() {

        WebDriverWait shortWait =
                new WebDriverWait(driver, Duration.ofSeconds(8));

        try {

            return shortWait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            errorMessages
                    )
            ).isDisplayed();

        } catch (Exception e) {

            return false;
        }
    }

    // Check whether still on login page
    public boolean isStillOnLoginPage() {

        return driver.getCurrentUrl().contains("/login");
    }
}
