
package lk.kdu.automation.tests;

import lk.kdu.automation.base.BaseTest;
import lk.kdu.automation.pages.LoginPage;
import lk.kdu.automation.pages.HomePage;
import lk.kdu.automation.pages.SearchResultsPage;
import lk.kdu.automation.utils.TestListener;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class SearchTest extends BaseTest {

    // Login and navigate to LinkedIn Home Page
    private HomePage loginAndGetHome() {

        String email = System.getenv("LINKEDIN_EMAIL");
        String password = System.getenv("LINKEDIN_PASSWORD");

        Assert.assertNotNull(
                email,
                "LinkedIn email environment variable is missing!"
        );

        Assert.assertNotNull(
                password,
                "LinkedIn password environment variable is missing!"
        );

        // Create LoginPage object
        LoginPage loginPage = new LoginPage(driver, wait);

        // Open LinkedIn Login Page
        loginPage.openLoginPage();

        // Enter credentials and login
        loginPage.login(email, password);

        // Create HomePage object
        HomePage home = new HomePage(driver);

        // Verify Home Page is loaded
        Assert.assertTrue(
                home.isLoaded(),
                "Home page should load after login"
        );

        return home;
    }

    // Test 1: Verify Search Results Page
    @Test(description = "Search shows results page")
    public void verifySearchResultsLoad() {

        HomePage home = loginAndGetHome();

        home.search("Software Engineer");

        SearchResultsPage results =
                new SearchResultsPage(driver);

        Assert.assertTrue(
                results.isLoaded(),
                "Search results page should load"
        );
    }

    // Test 2: Verify Search Returns Results
    @Test(description = "Search returns at least one result")
    public void verifySearchReturnsResults() {

        HomePage home = loginAndGetHome();

        home.search("QA Engineer");

        SearchResultsPage results =
                new SearchResultsPage(driver);

        Assert.assertTrue(
                results.isLoaded(),
                "Search results page should load"
        );

        Assert.assertTrue(
                results.getResultCount() > 0,
                "Expected at least one search result"
        );
    }
}
