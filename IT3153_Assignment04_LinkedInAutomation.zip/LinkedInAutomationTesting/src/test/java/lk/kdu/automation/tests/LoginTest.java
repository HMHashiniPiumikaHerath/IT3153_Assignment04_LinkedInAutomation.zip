
package lk.kdu.automation.tests;

import lk.kdu.automation.base.BaseTest;
import lk.kdu.automation.pages.LoginPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class LoginTest extends BaseTest {

    @Test
    public void validLoginTest() {

        String email = System.getenv("LINKEDIN_EMAIL");
        String password = System.getenv("LINKEDIN_PASSWORD");

        Assert.assertNotNull(email,
                "LinkedIn email environment variable is missing!");

        Assert.assertFalse(email.isBlank(),
                "LinkedIn email is empty!");

        Assert.assertNotNull(password,
                "LinkedIn password environment variable is missing!");

        Assert.assertFalse(password.isBlank(),
                "LinkedIn password is empty!");

        LoginPage loginPage = new LoginPage(driver, wait);

        loginPage.openLoginPage();

        loginPage.login(email, password);

        // Wait for LinkedIn to respond after Sign In
        try {
            new org.openqa.selenium.support.ui.WebDriverWait(
                    driver, Duration.ofSeconds(20)
            ).until(d ->
                    d.getCurrentUrl().contains("/feed")
                            || d.getCurrentUrl().contains("checkpoint")
                            || loginPage.isLoginErrorDisplayed()
            );
        } catch (Exception e) {
            System.out.println(
                    "Login result could not be identified within 20 seconds."
            );
        }

        // Verify actual login result
        String currentUrl = driver.getCurrentUrl();

        System.out.println("Current URL after login: " + currentUrl);

        Assert.assertTrue(
                currentUrl.contains("/feed"),
                "Login was not successful. Current URL: " + currentUrl
        );

        System.out.println("Valid login test passed successfully.");
    }
}
