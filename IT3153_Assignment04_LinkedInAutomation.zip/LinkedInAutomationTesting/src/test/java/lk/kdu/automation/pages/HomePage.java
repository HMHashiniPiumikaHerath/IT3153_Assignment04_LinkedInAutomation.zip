package lk.kdu.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By searchBox = By.cssSelector("input.search-global-typeahead__input");
    private final By feed      = By.cssSelector("main, div.scaffold-layout__main");

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public boolean isLoaded() {
        try {
            wait.until(ExpectedConditions.urlContains("/feed"));
            return wait.until(ExpectedConditions.visibilityOfElementLocated(feed)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void search(String keyword) {
        WebElement box = wait.until(ExpectedConditions.elementToBeClickable(searchBox));
        box.clear();
        box.sendKeys(keyword);
        box.sendKeys(Keys.ENTER);
    }
}